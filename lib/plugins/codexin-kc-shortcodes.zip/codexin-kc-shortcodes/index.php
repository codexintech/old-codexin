<?php 

// Silence is Golden